package com.GFL.lib.hardware.Encoder.Spark;

import com.GFL.lib.hardware.interfaces.GenericEncoder;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.sim.SparkMaxSim;
import com.revrobotics.sim.SparkRelativeEncoderSim;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.wpilibj.RobotBase;

public class SparkMaxRelativeEncoder implements GenericEncoder {
    private final RelativeEncoder encoder;
    private final SparkRelativeEncoderSim encoderSim;

    public SparkMaxRelativeEncoder(SparkMax motor, SparkMaxSim motorSim) {
        this.encoder = motor.getEncoder();
        this.encoderSim = motorSim.getRelativeEncoderSim();
    }

    @Override
    public double getPosition() {
        return RobotBase.isReal() ? encoder.getPosition() : encoderSim.getPosition();
    }

    @Override
    public double getVelocity() {
        return RobotBase.isReal() ? encoder.getVelocity() : encoderSim.getVelocity();
    }

    @Override
    public void setPosition(double position) {
        encoderSim.setPosition(position);
    }

    @Override
    public void setVelocity(double velocity) {
        encoderSim.setVelocity(velocity);
    }

    @Override
    public void reset() {
        encoder.setPosition(0);
    }
}