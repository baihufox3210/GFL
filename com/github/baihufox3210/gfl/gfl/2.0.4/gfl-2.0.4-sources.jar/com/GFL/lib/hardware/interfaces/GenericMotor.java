package com.GFL.lib.hardware.interfaces;

public interface GenericMotor {
    void configure();

    double getMotorVoltage();

    void set(double present);
    
    void setPosition(double position);
    void setVelocity(double velocity);

    void setMotionMagicPosition(double position);
    void setMotionMagicVelocity(double velocity);

    void simulationPeriodic();

    default void setAppliedOutput(double percent) {}
    
    default void setRawRotorPosition(double position) {};
    default void setRotorVelocity(double velocity) {};
    
    void stop();

    GenericEncoder getEncoder();
}