package com.GFL.lib.hardware.Encoder.Spark;

import com.GFL.lib.hardware.interfaces.GenericEncoder;
import com.revrobotics.AbsoluteEncoder;
import com.revrobotics.sim.SparkAbsoluteEncoderSim;
import com.revrobotics.sim.SparkMaxSim;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.RobotBase;

public class SparkMaxAbsoluteEncoder implements GenericEncoder {
    private final AbsoluteEncoder encoder;
    private final SparkAbsoluteEncoderSim encoderSim;

    public SparkMaxAbsoluteEncoder(SparkMax motor, SparkMaxSim motorSim) {
        this.encoder = motor.getAbsoluteEncoder();
        this.encoderSim = motorSim.getAbsoluteEncoderSim();
    }

    @Override
    public double getPosition() {
        return RobotBase.isReal() ? encoder.getPosition() : encoderSim.getPosition();
    }

    @Override
    public double getVelocity() {
        return RobotBase.isReal() ? encoder.getVelocity() : encoderSim.getVelocity();
    }

    @Override
    public void setPosition(double position) {
        encoderSim.setPosition(position);
    }

    @Override
    public void setVelocity(double velocity) {
        encoderSim.setVelocity(velocity);
    }
    
    @Override
    public void reset() {
        DriverStation.reportError("Cannot set position of an absolute encoder", false);
    }
}
