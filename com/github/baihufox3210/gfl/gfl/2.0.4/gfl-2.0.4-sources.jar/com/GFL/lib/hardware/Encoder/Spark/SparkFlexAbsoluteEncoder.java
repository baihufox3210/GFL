package com.GFL.lib.hardware.Encoder.Spark;

import com.GFL.lib.hardware.interfaces.GenericEncoder;
import com.revrobotics.AbsoluteEncoder;
import com.revrobotics.sim.SparkAbsoluteEncoderSim;
import com.revrobotics.sim.SparkFlexSim;
import com.revrobotics.spark.SparkFlex;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.RobotBase;

public class SparkFlexAbsoluteEncoder implements GenericEncoder {
    private final AbsoluteEncoder encoder;
    private final SparkAbsoluteEncoderSim encoderSim;

    public SparkFlexAbsoluteEncoder(SparkFlex motor, SparkFlexSim motorSim) {
        this.encoder = motor.getAbsoluteEncoder();
        this.encoderSim = motorSim.getAbsoluteEncoderSim();
    }

    @Override
    public double getPosition() {
        return RobotBase.isReal() ? encoder.getPosition() : encoderSim.getPosition();
    }

    @Override
    public double getVelocity() {
        return RobotBase.isReal() ? encoder.getVelocity() : encoderSim.getVelocity();
    }

    @Override
    public void setPosition(double position) {
        encoderSim.setPosition(position);
    }

    @Override
    public void setVelocity(double velocity) {
        encoderSim.setVelocity(velocity);
    }
    
    @Override
    public void reset() {
        DriverStation.reportError("Cannot set position of an absolute encoder", false);
    }
}
