package com.GFL.lib.hardware.interfaces;

public interface GenericEncoder {
    double getPosition();
    double getVelocity();

    void setVelocity(double velocity);
    void setPosition(double position);

    void reset();
}